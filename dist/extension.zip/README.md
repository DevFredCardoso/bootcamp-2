🌙 Modo Escuro Bootcamp
Funcionalidades
•	Alterna o tema da página ativa para modo escuro ou claro, vai da preferência do usuário
•	Mantém imagens, vídeos e banners intactos
•	Interface minimalista com botão que da pra mudar a hora que quiser

Modo Escuro Bootc(arquivos que fiz no vs code)
- manifest.json
- background.js
- popup.html
- popup.js
- style.css
- icons(pasta)
- icon.png
Como Botar no Google

1.	Baixe ou clone o repositório: git clone https://github.com/seu-usuario/modo-escuro-bootc.git
2.	Abra o Google e vá em: chrome://extensions/
3.	Ative o Modo do desenvolvedor 
4.	Clique em Carregar sem compactação
5.	Selecione a pasta do projeto modo-escuro-bootc/
6.	O ícone da extensão aparecerá ao lado da barra de endereço

🚀 Como usar

1.	Abra uma página
2.	Clique no ícone da extensão 🌙
3.	Clique no botão Alternar Tema
4.	O site vai mudar para “dark mode”
5.	Clique dnv para voltar ao modo claro

Tecnologias
•	Manifest V3
•	JavaScript (Chrome Scripting API)
•	HTML + CSS

📜 Licença
Este projeto está sob a licença MIT pode usar, modificar e distribuir
Como é um projeto de bootcamp, eu compartilhar e deixar outros usarem sem burocracia
MIT é aceito em praticamente todo lugar (GitHub, Chrome Web Store, NPM, etc)
Dá liberdade total pra quem for usar, mas me mantém como autor original
