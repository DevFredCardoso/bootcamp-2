chrome.runtime.onInstalled.addListener(() => {
    console.log("Dark Mode Switcher instalado!");
  });
